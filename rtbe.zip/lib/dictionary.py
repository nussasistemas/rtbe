def dictionary(inputArg1,inputArg2):

    api_url = 'https://od-api.oxforddictionaries.com/api/v1'
    api_id  = 'c0234f89'
    api_key = '417769d4472f6c0c7f6e570c2f8f5cb5'
    

    words = ['O','A','E','cavalo','montaria','branco','branca','pele','pêlo','cabelo','pêlos','pele','do','da','um','uma','é']
    return words
    #ordem = [1,9,13,4,6,17,6]


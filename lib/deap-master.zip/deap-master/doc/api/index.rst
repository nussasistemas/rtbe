Library Reference
=================

Description of the functions, classes and modules contained within DEAP.


.. toctree::
	:maxdepth: 2
   
	creator
	base
	tools
	algo
	gp
	benchmarks
